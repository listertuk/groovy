import com.atlassian.crowd.embedded.api.CrowdService
import com.atlassian.crowd.embedded.api.UserWithAttributes
import com.atlassian.crowd.embedded.impl.ImmutableUser
import com.atlassian.jira.bc.user.UserService
import com.atlassian.jira.bc.user.search.UserSearchParams
import com.atlassian.jira.bc.user.search.UserSearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.ApplicationUsers
import com.atlassian.jira.user.util.UserUtil
import org.apache.log4j.Logger

import com.atlassian.jira.mail.Email
import com.atlassian.jira.mail.settings.MailSettings
import com.atlassian.mail.MailException

import org.apache.log4j.Logger

Logger logit = Logger.getLogger("com.cheil.eu.logging")

int numOfDays = 25 // Number of days the user was not logged in
Date dateLimit = (new Date())- numOfDays

UserUtil userUtil = ComponentAccessor.userUtil
CrowdService crowdService = ComponentAccessor.crowdService
UserService userService = ComponentAccessor.getComponent(UserService)
UserSearchService userSearchService = ComponentAccessor.getComponent(UserSearchService.class);
UserSearchParams userSearchParams = new UserSearchParams(true, true, false);
List<ApplicationUser> userList = userSearchService.findUsers("", userSearchParams);
ApplicationUser updateUser
//UserService.UpdateUserValidationResult updateUserValidationResult
def userManager = ComponentAccessor.getUserManager()

String greeting = "Hello "
String body1 = "</br><p>Our Jira shows you have not logged into your Jira account for " + numOfDays + "days</br></br>" +
    "If you wish to continue using Jira please login as soon as possible."+
    "</br><p><a href='https://log.cheileu.com'>https://log.cheileu.com</a></br>"
    "</br> If your account remains unused Jira automation will disable the license after 30 days until access is requested</br></br>" +
    "To reactivate once disabled, please send a request to <a href=”mailto:helpdesk@cheil.com>Cheil Help Desk</a></br></br></p>" +
    "Regards<br>" +
    "Cheil IT UK</br>"
//+
//    "</br></br> Just to show we can run a schedule script to notify users and then deactivate them."

long count = 0

GroupManager groupManager = ComponentAccessor.getGroupManager();

userList.findAll{it.isActive()}.each {ApplicationUser it ->

    if(groupManager.isUserInGroup(it,"jira-administrators"))
        return;
    
    
	//def u = userManager.getUser(it)
    UserWithAttributes user = crowdService.getUserWithAttributes(it.getName())
    
    //def inactive = groupManager.getGroup("jira-inactive-users")
    //def active = groupManager.getGroup("jira-software-users")

    String lastLoginMillis = user.getValue('login.lastLoginMillis')
    if (lastLoginMillis?.isNumber()) {
        Date d = new Date(Long.parseLong(lastLoginMillis))
        if (d.before(dateLimit) &&  it.isActive() && groupManager.isUserInGroup(it,"jira-software-users")) {
            //groupManager.addUserToGroup(u, inactive)
            // userUtil.removeUserFromGroup(active, u)
            def bodytext = greeting + user.displayName + body1
            sendEmail(user.emailAddress, '[${user.name}] Your Jira account has not been used for ${numOfDays} days', bodytext)
            logit.info "Deactivate ${user.name} ${d} ${groupManager.getGroupNamesForUser(it.getName())}"
            count++
        }
    }
}

"${count} user to deactivate.\n"


String sendEmail(String emailAddr, String subject, String body) {
    // Stop emails being sent if the outgoing mail server gets disabled (useful if you start a script sending emails and need to stop it)
    def mailSettings = ComponentAccessor.getComponent(MailSettings)
    if (mailSettings?.send()?.disabled) {
        return "Your outgoing mail server has been disabled"
    }

    def mailServer = ComponentAccessor.mailServerManager.defaultSMTPMailServer
    if (!mailServer) {
        log.error("Your mail server Object is Null, make sure to set the SMTP Mail Server Settings Correctly on your Server")
        return "Failed to Send Mail. No SMTP Mail Server Defined"
    }

    def email = new Email(emailAddr)
    // email.setCc("michael.goral@cheil.com")
   // email.setCc("omair.irshad@cheil.com")
    email.setMimeType("text/html")
    email.setSubject(subject)
    email.setBody(body)
    try {
        mailServer.send(email)
        log.debug("Mail sent")
        //"Success"
    } catch (MailException e) {
        log.error("Send mail failed with error: ${e.message}") 
        //" Failed to Send Mail, Check Logs for error")
    }
}

//sendEmail('user@email.com', '<Your subject here>', '<Your body here>')




