
class TestClass {
    
    TestClass() {
        
    }
    
    String key
    String desc = "a peice of text"
}